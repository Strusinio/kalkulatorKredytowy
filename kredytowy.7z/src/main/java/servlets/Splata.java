package servlets;

public class Splata {
	Integer numerRaty;
	Double kwota;
	Double odsetki;
	Long oplaty;
	Double calowitaKwotaRaty;

	public Integer getNumerRaty() {
		return numerRaty;
	}

	public void setNumerRaty(Integer numerRaty) {
		this.numerRaty = numerRaty;
	}

	public Double getKwota() {
		return kwota;
	}

	public void setKwota(Double kwota) {
		this.kwota = kwota;
	}

	public Double getOdsetki() {
		return odsetki;
	}

	public void setOdsetki(Double odsetki) {
		this.odsetki = odsetki;
	}

	public Long getOplaty() {
		return oplaty;
	}

	public void setOplaty(Long oplaty) {
		this.oplaty = oplaty;
	}

	public Double getCalowitaKwotaRaty() {
		return calowitaKwotaRaty;
	}

	public void setCalowitaKwotaRaty(Double calowitaKwotaRaty) {
		this.calowitaKwotaRaty = calowitaKwotaRaty;
	}

}
